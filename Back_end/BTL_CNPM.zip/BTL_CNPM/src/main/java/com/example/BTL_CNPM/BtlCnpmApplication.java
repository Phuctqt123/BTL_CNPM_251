package com.example.BTL_CNPM;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BtlCnpmApplication {

	public static void main(String[] args) {
		SpringApplication.run(BtlCnpmApplication.class, args);
	}

}
